const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const app = express();

app.use(express.json());

// Connect to MongoDB Compass (local MongoDB server)
mongoose.connect('mongodb://127.0.0.1:27017/latexDB')
  .then(() => console.log('Connected to MongoDB'))
  .catch((error) => console.error('Error connecting to MongoDB:', error));

// Define the LaTeX schema and model
const latexSchema = new mongoose.Schema({
  label: { type: String, required: true },
  latexCode: { type: String, required: true },
});

const Latex = mongoose.model('Latex', latexSchema);

// Serve the index.html file for the root route
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// API to save LaTeX code and label
app.post('/saveLatex', async (req, res) => {
  const { label, latexCode } = req.body;

  if (!label || !latexCode) {
    return res.status(400).send('Label and LaTeX code are required.');
  }

  try {
    const newLatex = new Latex({ label, latexCode });
    await newLatex.save();
    res.status(201).send('LaTeX code saved successfully.');
  } catch (error) {
    console.error('Error saving LaTeX code:', error);
    res.status(500).send('Failed to save LaTeX code.');
  }
});

// Start the server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
